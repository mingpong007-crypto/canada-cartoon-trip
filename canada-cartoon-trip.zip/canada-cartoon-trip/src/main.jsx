import React, { useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { motion, AnimatePresence } from 'framer-motion'
import { Plane, MapPin, Sparkles, Camera, CalendarDays, Heart, Play, ChevronRight, RotateCcw } from 'lucide-react'
import './style.css'

const scenes = [
  {date:'10月1日', title:'飞机降落温哥华', place:'YVR 机场', emoji:'✈️', text:'爸爸和妹妹终于来到加拿大！云朵让路，小飞机带着期待降落。'},
  {date:'10月2日', title:'温哥华市中心散步', place:'Canada Place', emoji:'🏙️', text:'海边风很舒服，白色帆船屋像童话里的城堡。'},
  {date:'10月3日', title:'史丹利公园小探险', place:'Stanley Park', emoji:'🌲', text:'骑车、看海、找松鼠，一起收集第一张旅行贴纸。'},
  {date:'10月4日', title:'格兰维尔岛甜甜日', place:'Granville Island', emoji:'🍩', text:'市场里有水果、甜点和街头表演，像彩色动画市集。'},
  {date:'10月5日', title:'卡皮拉诺吊桥勇气挑战', place:'Capilano', emoji:'🌉', text:'一步一步走过森林吊桥，勇气值 +100！'},
  {date:'10月6日', title:'海天公路风景线', place:'Sea to Sky', emoji:'🚗', text:'窗外是山、海和云，像进入一条会发光的路线。'},
  {date:'10月7日', title:'惠斯勒雪山小镇', place:'Whistler', emoji:'🏔️', text:'小镇有木屋、咖啡和山景，拍下最可爱的家庭合照。'},
  {date:'10月8日', title:'维多利亚童话花园', place:'Victoria', emoji:'🌸', text:'坐船去岛上，看花园和英式建筑，像走进明信片。'},
  {date:'10月9日', title:'列治文美食地图', place:'Richmond', emoji:'🍜', text:'今天是吃吃吃模式，热汤面、点心和甜品全部打卡。'},
  {date:'10月10日', title:'北温山海缆车', place:'Grouse Mountain', emoji:'🚡', text:'坐缆车往上飞，城市慢慢变小，天空变得更近。'},
  {date:'10月11日', title:'温哥华水族馆', place:'Vancouver Aquarium', emoji:'🐠', text:'小鱼游来游去，妹妹发现了最像动画角色的海洋朋友。'},
  {date:'10月12日', title:'家庭购物纪念日', place:'Outlet / Mall', emoji:'🛍️', text:'买一点纪念品，把加拿大的小幸福装进行李箱。'},
  {date:'10月13日', title:'最后的夕阳合照', place:'English Bay', emoji:'🌅', text:'夕阳把海边染成橙色，今天的照片特别温柔。'},
  {date:'10月14日', title:'旅行相册完成', place:'Canada Memories', emoji:'📚', text:'14天的小冒险变成一本会动的家庭纪念册。'}
]

const characters = [
  {name:'我', role:'加拿大小导游', emoji:'🧢', color:'mint'},
  {name:'爸爸', role:'勇敢旅行家', emoji:'👨', color:'sun'},
  {name:'妹妹', role:'可爱摄影师', emoji:'👧', color:'pink'}
]

function FloatingClouds(){
  return <div className="sky-layer" aria-hidden="true">
    {[...Array(8)].map((_,i)=><motion.div key={i} className={`cloud cloud-${i+1}`} animate={{x:[-30,30,-30], y:[0,-8,0]}} transition={{duration:7+i, repeat:Infinity, ease:'easeInOut'}} />)}
    <motion.div className="plane" animate={{x:['-20vw','110vw'], y:[18,-20,22]}} transition={{duration:16, repeat:Infinity, ease:'linear'}}><Plane size={42}/></motion.div>
  </div>
}

function ProgressMap({index}){
  const pct = ((index + 1) / scenes.length) * 100
  return <div className="map-card">
    <div className="map-head"><span><MapPin size={18}/> 冒险路线</span><b>{Math.round(pct)}%</b></div>
    <div className="route"><motion.div className="route-fill" initial={false} animate={{width:`${pct}%`}} transition={{type:'spring', stiffness:80, damping:18}} /></div>
    <div className="route-dots">{scenes.map((s,i)=><button key={s.date} className={i<=index?'dot active':'dot'} title={s.title}/>)}</div>
  </div>
}

function SceneCard({scene,index}){
  return <motion.article className="scene-card" key={scene.date} initial={{opacity:0, scale:.9, y:30, rotate:-1}} animate={{opacity:1, scale:1, y:0, rotate:0}} exit={{opacity:0, scale:.94, y:-20}} transition={{type:'spring', stiffness:110, damping:16}}>
    <motion.div className="big-emoji" animate={{rotate:[-4,4,-4], y:[0,-8,0]}} transition={{duration:3, repeat:Infinity}}>{scene.emoji}</motion.div>
    <div className="badge"><CalendarDays size={16}/>{scene.date}</div>
    <h2>{scene.title}</h2>
    <p className="place"><MapPin size={16}/>{scene.place}</p>
    <p>{scene.text}</p>
    <div className="sticker-row"><span>⭐ 第 {index+1} 幕</span><span>🎒 家庭冒险</span><span>📸 纪念贴纸</span></div>
  </motion.article>
}

function App(){
  const [index,setIndex]=useState(0)
  const scene=scenes[index]
  const memory = useMemo(()=>scenes.slice(0,index+1),[index])
  const next=()=>setIndex(i=>(i+1)%scenes.length)
  const reset=()=>setIndex(0)
  return <main>
    <FloatingClouds/>
    <section className="hero">
      <motion.div className="title-pill" initial={{opacity:0,y:-20}} animate={{opacity:1,y:0}}><Sparkles size={18}/> 可爱卡通动画 App</motion.div>
      <motion.h1 initial={{opacity:0,y:24}} animate={{opacity:1,y:0}} transition={{delay:.1}}>爸爸和妹妹的<br/>加拿大小冒险</motion.h1>
      <motion.p className="subtitle" initial={{opacity:0}} animate={{opacity:1}} transition={{delay:.25}}>10月1日 — 10月14日 · 温哥华家庭旅行动画片</motion.p>
      <div className="character-grid">{characters.map((c,i)=><motion.div className={`character ${c.color}`} key={c.name} initial={{opacity:0,y:30}} animate={{opacity:1,y:0}} transition={{delay:.2+i*.12}} whileHover={{y:-8, rotate:i-1}}><div>{c.emoji}</div><b>{c.name}</b><span>{c.role}</span></motion.div>)}</div>
    </section>
    <section className="stage">
      <ProgressMap index={index}/>
      <AnimatePresence mode="wait"><SceneCard scene={scene} index={index}/></AnimatePresence>
      <div className="controls"><motion.button whileTap={{scale:.95}} onClick={next}><Play size={18}/> 播放下一幕 <ChevronRight size={18}/></motion.button><button className="ghost" onClick={reset}><RotateCcw size={18}/> 重看开头</button></div>
    </section>
    <section className="album">
      <h2><Camera/> 已解锁旅行相册</h2>
      <div className="album-grid">{memory.map((m,i)=><motion.div className="photo" key={m.date} initial={{opacity:0,scale:.8}} animate={{opacity:1,scale:1}}><span>{m.emoji}</span><b>{m.date}</b><small>{m.title}</small></motion.div>)}</div>
    </section>
    <footer><Heart size={16}/> Made for family memories in Canada</footer>
  </main>
}

createRoot(document.getElementById('root')).render(<App />)

# 爸爸和妹妹的加拿大小冒险

Cute cartoon animated travel app for a Canada family trip, Oct 1–14.

## Run
npm install
npm run dev

## Build
npm run build
